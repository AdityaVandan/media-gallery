﻿using System;

namespace BlockChainDemo
{
    public class Node
    {
        public Uri Address { get; set; }
    }
}