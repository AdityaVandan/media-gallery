import React from 'react';

import NavigationBar from '../../components/NavigationBar';
import MovieSection from './MovieSection';
import ShowSection from './ShowSection';
import ListMedia from './ListMedia';

import './index.css';
import { Link, Route, Switch, useHistory, useLocation } from 'react-router-dom';


class Home extends React.Component{
    state = {
        currentMedia: "movie"
    }

    selectTab = (event) => {
        console.log(this.props)
        if(this.state.currentMedia === event.target.id) return;
        let element = event.target.id;
        if(element === "movie"){
            this.props.history.push('/home/movie');
            this.setState({...this.state,
                currentMedia: "movie"
            });
        }else{
            this.props.history.push('/home/show');
            this.setState({...this.state,
                currentMedia: "show"
            });            
        }
    }


    render(){
        return (
            <div className="home-div">
                <NavigationBar />
                <div className="tab-div">
                    <span id="movie" className={this.state.currentMedia==="movie"?"tab-selected":"tab"} onClick={this.selectTab}>Movies</span>
                    <span id="show" className={this.state.currentMedia==="show"?"tab-selected":"tab"} onClick={this.selectTab}>TV shows</span>
                </div>
                <Route {...this.props} path="/home/movie" component={MovieSection}  />
                <Route {...this.props} path="/home/show" component={ShowSection}  />
            </div>
        )
    }
}
export default Home;