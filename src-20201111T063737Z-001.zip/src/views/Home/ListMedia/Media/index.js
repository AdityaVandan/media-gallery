import React from 'react';

import Card from '../../../../ui/Card';
import Button from '../../../../ui/Button'

import './index.css';

class Media extends React.Component{
    getDescription = (id) =>{
        alert(id);
    }
    render(){
        return (
            <Card>
                <div className="media-div">
                    <img className="media-image" src={this.props.media.image} alt="Loading..." />
                    <h1>{this.props.media.title?this.props.media.title:this.props.media.name}</h1>
                    <p style={{color: "#05386b"}}><b>Rating:</b> <i className="fa fa-star-half-o" aria-hidden="true"></i> {this.props.media.vote_average}/10</p>
                    <Button onClick={this.getDescription.bind(this,this.props.media.id)}>Know More <i className="fa fa-angle-right" aria-hidden="true"></i></Button>
                </div>
            </Card>
        )
    }
}
export default Media;