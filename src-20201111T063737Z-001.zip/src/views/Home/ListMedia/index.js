import React from 'react';
import axios from 'axios';

import Media from './Media';
import './index.css';
import api_constants from '../../../constants/constants';

class ListMedia extends React.Component{
    state = {};

    componentDidMount(){
        let url = `${this.props.api}?api_key=${api_constants.API_KEY}`;
        axios.get(url).then((res) => {
            let medialist = res.data.results;
            for(let i=0;i<medialist.length;i++){
                if(medialist[i].backdrop_path!==null) medialist[i].image = `https://image.tmdb.org/t/p/original${medialist[i].backdrop_path}`;
                else medialist[i].image = `https://image.tmdb.org/t/p/original${medialist[i].poster_path}`;
            }
            let newMediaList = [];
            let pair=[];
            for(let i=0;i<medialist.length;i++){
                pair.push(medialist[i]);
                if(i%2==1){
                    newMediaList.push(pair);
                    pair = [];
                }
            }
            console.log(newMediaList);
            this.setState({...this.state,
            mediaRowlist: newMediaList
            });
            console.log(medialist);
        }).catch((err) => {
            console.log(err);
        });
    }
    render(){
        return (
            <div className="listmedia">
                    {this.state.mediaRowlist?this.state.mediaRowlist.map((mediaPair,index) => {
                        return (
                            <div key={`${mediaPair[0].id}-${index}row`} className="listmedia-row">
                                {mediaPair.map((media,index) => {
                                    return (
                                        <div key={`${media}#${index}`} className="listmedia-column">
                                        <Media media={media} />
                                        </div>
                                    )
                                })}
                            </div>
                        )
                    }):null}

            </div>
        )
    }
}
export default ListMedia;