import React from 'react';
import {Link} from 'react-router-dom'
import axios from 'axios';

import NavigationBar from '../../components/NavigationBar';
import Card from '../../ui/Card';
import Row from '../../ui/Row';
import Column from '../../ui/Column';
import Button from '../../ui/Button';
import api_constants from '../../constants/constants';

import './index.css';


class Description extends React.Component{
    state = {
        name: "loading...",
        image: "",

    }
    componentDidMount = () => {
        let media = this.props.match.params.media;
        let id = this.props.match.params.id;
        let url;
        if(media === "movie"){
            url = `${api_constants.MOVIE_DESCRIPTION_API_END}${id}?api_key=${api_constants.API_KEY}`;
            axios.get(url).then(res => {
                let movie = res.data;
                movie.poster = `https://image.tmdb.org/t/p/original/${movie.poster_path}`;
                movie.image = `https://image.tmdb.org/t/p/original/${movie.backdrop_path}`;
                console.log(res.data);
                this.setState({...this.state,
                    ...movie
                });
            }).catch(err => {
                console.log(err);
            });
        }else if(media === "show"){
            url = `${api_constants.SHOW_DESCRIPTION_API_END}${id}?api_key=${api_constants.API_KEY}`;

        }else{
            this.props.history.push("/");
        }
        console.log(window.location.href)
    }

    back= () => {
        this.props.history.push("/home");
    }

    render(){
        let textColor = "#05386b";
        console.log(this.props.match.params);
        console.log("state");
        console.log(this.state);
        console.log(this.state.genres);
        return (
            <div>
                <NavigationBar />
                <Card>
                    <Row>
                        <Column>
                            <img className="poster" src={this.state.poster} alt="loading..." />
                        </Column>
                        <h2 style={{color: textColor}}>{this.state.original_title}</h2>
                        <Column>
                            <Card>
                                <div className="description-div">
                                    <p><b style={{color: textColor}}>Synopsis:</b> {this.state.overview}</p>
                                    {this.state.genres?
                                    <div>
                                        <h4 style={{color: textColor}}>Genres</h4>
                                        <ul>
                                            {this.state.genres.map((genre,index) => {return (<li key={`genre${genre.id}`}>{genre.name}</li>)})}
                                        </ul>
                                    </div>:null}
                                    <p><b style={{color: textColor}}>Runtime:</b> {`${this.state.runtime} min`}</p>
                                    <p><b style={{color: textColor}}>Voters:</b> {`${this.state.vote_count} people`}</p>
                                    <p><b style={{color: textColor}}>Rating:</b> {`${this.state.vote_average}/10`}</p>
                                    <p><b style={{color: textColor}}>Website:</b> <a href={this.state.homepage}>{this.state.homepage}</a></p>
                                    <p><b style={{color: textColor}}>release_date:</b> {this.state.release_date}</p>
                                </div>
                            </Card>
                        </Column>
                        <Column>
                            <Card>
                                <div className="description-div">
                                    <h4 style={{color: textColor}}>Media Images:</h4>
                                    {<ul>
                                        <li><a href={this.state.poster}>Image 1</a></li>
                                        <li><a href={this.state.image}>Image 2</a></li>
                                    </ul>}
                                    {this.state.production_companies?
                                    <div>
                                        <h4 style={{color: textColor}}>Production Companies</h4>
                                        <ul>
                                            {this.state.production_companies.map((company,index) => {return (<li key={`company${company.id}`}>{company.name}</li>)})}
                                        </ul>
                                    </div>:null}
                                    <p><b style={{color: textColor}}>Budget:</b> {`$${this.state.budget}`}</p>
                                    <p><b style={{color: textColor}}>Revenue:</b> {`$${this.state.revenue}`}</p>
                                </div>
                                <Button onClick={this.back}><i className="fa fa-left"></i>back to home</Button>
                            </Card>
                        </Column>
                    </Row>

                </Card>
            </div>
        )
    }
}
export default Description;