import React from 'react';

import Navigationbar from '../NavigationBar';

import './index.css';

class SearchBar extends React.Component{
    render(){
        return (
        <div className="search-bar">
            <input className="search-input" placeholder="search media" />
            <button type="button" className="search-button">Search</button>
        </div>
        )
    }
}
export default SearchBar;