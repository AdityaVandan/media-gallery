import React from 'react';
import axios from 'axios';

import api_constants from "../../constants/constants";

import './index.css';

class Carousel extends React.Component{
    constructor(props){
        super(props);
        let trendingMedia = [];
        let images = ["https://sf-applications.s3.amazonaws.com/Bear/wallpapers/05/july-2020-wallpaper_desktop-3840x1600.png","https://wallpapercave.com/wp/wp2646303.jpg","http://placekitten.com/1600/900","http://placekitten.com/g/1600/900","https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__340.jpg"];
        for(let i=0;i<images.length;i++) trendingMedia.push({image: images[i],className:"carousel__photo"});
        trendingMedia[trendingMedia.length-1].className="carousel__photo prev";
        trendingMedia[0].className = "carousel__photo active";
        trendingMedia[1].className = "carousel__photo next";
        this.state = {msg:"nothing",
            trendingMedia: trendingMedia
        };
    }

    async componentDidMount(){
        console.log("component did mount");

        let url = this.props.api+"?api_key="+api_constants.API_KEY
        await axios.get(url).then(res => {
            let trendingMedia = res.data.results;
            for(let i=0;i<trendingMedia.length;i++){
                trendingMedia[i].className = "carousel__photo";
                trendingMedia[i].image = "https://image.tmdb.org/t/p/original" + trendingMedia[i].backdrop_path
            }
            trendingMedia[trendingMedia.length-1].className = "carousel__photo prev";
            trendingMedia[0].className = "carousel__photo active";
            trendingMedia[1].className = "carousel__photo next";
            console.log(res.data);

            this.setState({ ...this.state,trendingMedia:trendingMedia, msg: "I got movies"});
        }).catch((err) => {
            this.setState({...this.state, msg: "error is here"});
        });
        setInterval(this.next,5000);
        return;
    }
    next = () => {
        let totalImages = this.state.trendingMedia.length;
        let obj = JSON.parse(JSON.stringify(this.state));
        let trendingMedia = obj.trendingMedia;
        let index = this.state.trendingMedia.findIndex(media => media.className.includes("active"));
        for(let i=0;i<totalImages;i++) trendingMedia[i].className = "carousel__photo";

        if(index === (totalImages-2)){
            trendingMedia[index].className = "carousel__photo prev";
            trendingMedia[index+1].className = "carousel__photo active";
            trendingMedia[0].className = "carousel__photo next"; 
        }else if(index === (totalImages-1)){
            trendingMedia[index].className = "carousel__photo prev";
            trendingMedia[0].className = "carousel__photo active";
            trendingMedia[1].className = "carousel__photo next"; 
        }else{
            trendingMedia[index].className = "carousel__photo prev";
            trendingMedia[index+1].className = "carousel__photo active";
            trendingMedia[index+2].className = "carousel__photo next"; 
        }
        this.setState({...this.state, trendingMedia:trendingMedia});

    }
    previous = () =>{
        let totalImages = this.state.trendingMedia.length;
        let obj = JSON.parse(JSON.stringify(this.state));
        let trendingMedia = obj.trendingMedia;
        let index = this.state.trendingMedia.findIndex(media => media.className.includes("active"));
        for(let i=0;i<totalImages;i++) trendingMedia[i].className = "carousel__photo";

        if(index === 1){
            trendingMedia[index].className = "carousel__photo next";
            trendingMedia[index-1].className = "carousel__photo active";
            trendingMedia[totalImages-1].className = "carousel__photo prev"; 
        }else if(index === 0){
            trendingMedia[index].className = "carousel__photo next";
            trendingMedia[totalImages-1].className = "carousel__photo active";
            trendingMedia[totalImages-2].className = "carousel__photo prev"; 
        }else{
            trendingMedia[index].className = "carousel__photo next";
            trendingMedia[index-1].className = "carousel__photo active";
            trendingMedia[index-2].className = "carousel__photo prev"; 
        }
        this.setState({...this.state, trendingMedia:trendingMedia});
    }

    onImageClick = (id) =>{
        console.log(this.props);
        if(this.props.api.includes("movie")){
            // this.props.history.push(`/description/movie/${id}`);
        }else{

        }
        // this.props.history.push(`/description/`)
    }

    render(){
        return (
            <div className="carsouel-section">
                <div className="carousel-wrapper">
                    <div className="carousel">
                        {this.state.trendingMedia.map((cn,index) => {return (<img id={"img"+index} key={"img"+index} className={cn.className} src={cn.image} onClick={this.onImageClick.bind(this,cn.id)} />) })}
                        <div className="carousel__button--next" onClick={this.next}></div>
                        <div className="carousel__button--prev" onClick={this.previous}></div>
                    </div>
                </div>
            </div>
        )
    }
}
export default Carousel;