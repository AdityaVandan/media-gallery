import React from 'react';

import Navigationbar from '../NavigationBar';

import './index.css';

class ComponentNotFound extends React.Component{
    render(){
        return (
        <div className="error404">
            <Navigationbar />
            <div className="heading-section">
            <h1>404 not found</h1>
            </div>
        </div>
        )
    }
}
export default ComponentNotFound;