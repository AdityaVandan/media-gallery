import React from 'react';
import {Link} from 'react-router-dom';

import './index.css';

class NavigationBar extends React.Component{
    render(){
        return (
            <div className="Navbar">
                {/* <h1 className="NavbarTitle"><Link activeClassName = "NavbarTitle" to="/hr">Media Gallery</Link></h1> */}
                <h1 className="NavbarTitle">Media Gallery</h1>
            </div>
        )
    }
}
export default NavigationBar;